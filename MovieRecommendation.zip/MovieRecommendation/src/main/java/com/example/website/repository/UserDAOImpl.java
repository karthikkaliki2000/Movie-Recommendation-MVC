package com.example.website.repository;

import java.util.ArrayList;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.example.website.domain.User;

@Repository
@Scope("singleton")
public class UserDAOImpl implements UserDAO {

	ArrayList<User> users=new ArrayList<User>();
	@Override
	public void CreateUser(User user) {
		// TODO Auto-generated method stub
	System.out.println("user created");
		
		

	}

	@Override
	public String saveUser(User user) {
		// TODO Auto-generated method stub
		users.add(user);
		return user.getUserName();
	}

}
