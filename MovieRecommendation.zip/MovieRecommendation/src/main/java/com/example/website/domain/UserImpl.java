package com.example.website.domain;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.website.repository.UserDAO;

@Component
public class UserImpl implements User {
	String userName;
	String email;
	String password;
	
	@Autowired
	UserDAO userDAO;
	@Override
	public String getUserName() {
		// TODO Auto-generated method stub
		return this.userName;
	}

	public UserImpl() {
		super();
	}
	
	

	public UserImpl(String userName, String email, String password, UserDAO userDAO) {
		super();
		this.userName = userName;
		this.email = email;
		this.password = password;
		this.userDAO = userDAO;
	}

	@Override
	public String getEmail() {
		// TODO Auto-generated method stub
		return this.email;
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return this.password;
	}

	@Override
	public void setUserName(String name) {
		// TODO Auto-generated method stub
		this.userName=name;
		
		
	}

	@Override
	public void setEmail(String email) {
		// TODO Auto-generated method stub
		this.email=email;
		
		
	}

	@Override
	public void setPassword(String password) {
		// TODO Auto-generated method stub
		this.password=password;
		
	}

	@Override
	public void CreateUser(String name, String email, String password) {
		// TODO Auto-generated method stub
		this.setEmail(email);
		this.setUserName(name);
		this.setPassword(password);
		
	}

	@Override
	public String saveUser(String name, String email, String password) {
		// TODO Auto-generated method stub
		this.setEmail(email);
		this.setUserName(name);
		this.setPassword(password);
userDAO.CreateUser(this);

		return userDAO.saveUser(this);
	}

}
