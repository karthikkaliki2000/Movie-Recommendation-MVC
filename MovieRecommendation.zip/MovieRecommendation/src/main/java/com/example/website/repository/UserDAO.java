package com.example.website.repository;

import com.example.website.domain.User;

public interface UserDAO {
	public void CreateUser(User user);
	public String saveUser(User user);
}
