package com.example.website.service;

import com.example.website.domain.User;

public interface UserService {
	
	public void CreateUser(String name,String email, String password);
	public String saveUser(String name,String email, String password);
	public User getUser();
}
