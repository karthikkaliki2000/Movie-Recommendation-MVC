package com.example.website.web;

import com.example.website.domain.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.website.service.UserService;


@Controller
public class SignUpController {

	@Autowired
	@Qualifier("userServiceImpl")
	UserService userService;
	
	
	public void SignUpController() {
		
	}
	
	
	
	@RequestMapping("/signup")
	public String userinfo(ModelMap	model) {
	
	   User user=userService.getUser();
	   model.addAttribute("user", user);
	   return "signup";
	}
	

	@RequestMapping("/success")
	public String success( @ModelAttribute("user") UserImpl user,ModelMap map) {
		userService.CreateUser(user.getUserName(), user.getPassword(), user.getEmail());
		String name=userService.saveUser(user.getUserName(), user.getPassword(), user.getEmail());
		
		if(name.isBlank() || name.isEmpty()) {
			return "signup";
		}
		
		map.addAttribute("name", name);
		return "success";
	}
	
	
	@RequestMapping("/genres/{userName}")
	public String showGenres(@PathVariable("userName") String name,ModelMap map) {
		List<String> genres=new ArrayList<String>();
		
		genres.add("Fable");
		genres.add("Fantasy");
		genres.add("Fiction");
		genres.add("Fiction In Verse");
		genres.add("FolkLore");
		map.addAttribute("genres", genres);
		
		return "genrepage";
	}
	
	@RequestMapping("/recommended")
	public String Recomneded(ModelMap map) {
List<String> movies=new ArrayList<String>();
		
movies.add("harry potter");
movies.add("Cinderalla");
movies.add("spiderman");
movies.add("Infinity war");
movies.add("Avengers end game");
movies.add("Iron man");
movies.add("Snow age");

		map.addAttribute("movies", movies);
		return "recommended";
	}
	
	@RequestMapping("/thankyou")
	public String thankYou() {
		return "thankyou";
	}
	
	
}
