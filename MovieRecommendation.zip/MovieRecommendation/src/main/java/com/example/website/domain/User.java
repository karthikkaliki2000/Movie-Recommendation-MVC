package com.example.website.domain;

public interface User {
	
	
	public String getUserName();
	
	public String getEmail();
	public String getPassword();
     public void setUserName(String name);
	
	public void setEmail(String email);
	public void setPassword(String password);
	public void CreateUser(String name,String email, String password);
	public String saveUser(String name,String email, String password);
	
}
