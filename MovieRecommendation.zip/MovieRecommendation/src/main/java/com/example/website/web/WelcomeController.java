package com.example.website.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.website.domain.User;

@Controller
public class WelcomeController {

	@RequestMapping(value="/welcome")
	public String getHomePage(Model model) {
		
		return "welcome";
	}
}
