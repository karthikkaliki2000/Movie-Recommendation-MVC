package com.example.website.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.website.domain.User;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	User user;
	@Override
	public void CreateUser(String name, String email, String password) {
		// TODO Auto-generated method stub
		user.CreateUser(name, email, password);
		
		
	}

	@Override
	public String saveUser(String name, String email, String password) {
		// TODO Auto-generated method stub
		return user.saveUser(name, email, password);
	}

	@Override
	public User getUser() {
		// TODO Auto-generated method stub
		return user;
	}

}
